"use client"

import VoiceChatbot from "../pages/index"

export default function SyntheticV0PageForDeployment() {
  return <VoiceChatbot />
}